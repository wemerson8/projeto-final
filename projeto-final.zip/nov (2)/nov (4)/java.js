{
let contador =  0
let res = document.querySelector('section#result')
function adicionar() {
  contador += 250;
    res.innerHTML = `${contador}`
   
}


function diminuir() {
    contador -=250
    res.innerHTML = `${contador }`
}
}
{
let contador =  0
let res = document.querySelector('section#rest')
function adiciona() {
  contador += 250;
    res.innerHTML = `${contador}`
   
}


function diminui() {
    contador -=250
    res.innerHTML = `${contador }`

}
} 
{
let contador =  0
let res = document.querySelector('section#data')
function mais() {
  contador += 
    res.innerHTML = `${contador}`
   
}
  

function menos() {
    contador -=
    res.innerHTML = `${contador }`
}
}

let res = document.querySelector('id#go')
res.innerHTML = `${cou}` 